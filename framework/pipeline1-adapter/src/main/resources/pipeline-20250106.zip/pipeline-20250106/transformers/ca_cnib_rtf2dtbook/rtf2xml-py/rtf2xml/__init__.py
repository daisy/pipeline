'''
modules for rtf2xml
'''
